#ifndef CONFIG_H
#define CONFIG_H

#include <iostream>

namespace Config{
    const std::string API_KEY = "bL4B-uoY";
    const std::string CLIENT_SECRET = "5CX0rzMbCfHzlzN6MXgRIR6Yq_p_jZKUtxrNLWYLvpM";
    const std::string BASE_URL = "https://test.deribit.com/api/v2/";
    const std::string GET = "GET";
    const std::string POST = "POST";
};

#endif // CONFIG_H